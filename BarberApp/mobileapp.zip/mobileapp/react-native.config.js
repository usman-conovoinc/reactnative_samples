module.exports = {
    project: {
        ios: {},
        android: {}
    },
    assets: ['./app/assets/fonts'],
}
